# Flo Personal v0.1

This version is designed specifically for your phone as a private personal-use PWA.

### Included
- Installable PWA shell
- Offline service worker/cache
- Local persistent storage using `localStorage`
- Starting balance + income - expenses
- Transaction-driven Money Flow Estuary
- Actual transaction particles
- Multi-currency and crypto accounts
- Personal wealth thresholds and heart animation
- Transaction entry/deletion
- Account entry/deletion
- JSON backup export

### Deploy to Vercel
1. Upload this project to GitHub, or use Vercel Drop.
2. Import/deploy the Vite project.
3. Vercel detects Vite and can deploy the project with the normal Vite build output. 
4. Open the deployed URL on your Android phone.
5. In Chrome use the browser menu and choose the install/add-to-home-screen option.

### Important
This personal version deliberately stores data locally on the device. It does not send your financial data to a database.

For now, treat it as a personal prototype rather than a production financial service. Keep a regular JSON backup using the download button.

### v0.2
- Bidirectional Estuary: income sources flow into Flo and expenses flow out.
- Existing local-storage keys are preserved.
- Added Household as a dedicated expense category for repairs, maintenance, appliances, furniture, cleaning, and household supplies.
- Added income source categories: Salary, Business income, Investment, Gift, Other income.
- Existing transactions are not automatically reclassified.
