
import React,{useEffect,useMemo,useState} from "react";
import {createRoot} from "react-dom/client";
import {Plus,Download,Trash2} from "lucide-react";
import "./style.css";

const currencies=[
["NGN","🇳🇬 Nigerian Naira","₦",1],["USD","🇺🇸 US Dollar","$",1500],["EUR","🇪🇺 Euro","€",1750],["GBP","🇬🇧 British Pound","£",2020],
["CAD","🇨🇦 Canadian Dollar","C$",1080],["AUD","🇦🇺 Australian Dollar","A$",980],["CHF","🇨🇭 Swiss Franc","CHF",1870],
["JPY","🇯🇵 Japanese Yen","¥",10.2],["CNY","🇨🇳 Chinese Yuan","¥",210],["AED","🇦🇪 UAE Dirham","د.إ",410],
["ZAR","🇿🇦 South African Rand","R",82],["GHS","🇬🇭 Ghanaian Cedi","₵",120],
["BTC","₿ Bitcoin","BTC",150000000],["ETH","Ξ Ethereum","ETH",6500000],["USDT","₮ Tether","USDT",1500],["USDC","◎ USD Coin","USDC",1500]
];
const categories=[{name:"Business",color:"#43a8ff"},{name:"Food & Dining",color:"#55c878"},{name:"Transport",color:"#e2ad45"},{name:"Utilities",color:"#e75f50"},{name:"Household",color:"#d78cff"},{name:"Other",color:"#a879ff"}];
const paths=["M150 260 C310 260 350 105 520 90 S760 85 930 85","M150 260 C310 260 360 205 520 190 S770 185 930 185","M150 260 C310 260 380 270 540 280 S770 280 930 280","M150 260 C300 260 380 335 540 355 S770 355 930 355","M150 260 C300 260 380 415 540 430 S770 430 930 430"];
const initialTransactions=[
{id:1,description:"Business supplies",amount:100000,category:"Business",account:"GTBank",cur:"NGN",type:"expense",date:"Today"},
{id:2,description:"Groceries",amount:18500,category:"Food & Dining",account:"GTBank",cur:"NGN",type:"expense",date:"Today"},
{id:3,description:"Transport",amount:8000,category:"Transport",account:"GTBank",cur:"NGN",type:"expense",date:"Yesterday"},
{id:4,description:"Electricity",amount:14500,category:"Utilities",account:"GTBank",cur:"NGN",type:"expense",date:"Yesterday"},
{id:5,description:"Salary",amount:120000,category:"Salary",account:"GTBank",cur:"NGN",type:"income",date:"3 days ago"}];
const initialAccounts=[{name:"GTBank",cur:"NGN",bal:2450000,type:"Bank account"},{name:"USD Account",cur:"USD",bal:4250,type:"Bank account"},{name:"Bitcoin Wallet",cur:"BTC",bal:.045,type:"Crypto wallet"}];
const incomeCategories=["Salary","Business income","Investment","Gift","Other income"];
const incomeColors=["#55c878","#43a8ff","#e2ad45","#a879ff","#9aa7a1"];
const incomePaths=["M500 260 C420 230 330 95 180 70","M500 260 C420 245 340 150 180 145","M500 260 C420 255 340 215 180 215","M500 260 C420 275 340 325 180 325","M500 260 C420 290 330 410 180 410"];


function money(n,cur="NGN"){const c=currencies.find(x=>x[0]===cur)||currencies[0];return c[2]+Math.round(n).toLocaleString()}
function useStored(key,fallback){const [v,setV]=useState(()=>{try{const x=localStorage.getItem(key);return x?JSON.parse(x):fallback}catch{return fallback}});useEffect(()=>localStorage.setItem(key,JSON.stringify(v)),[key,v]);return [v,setV]}

function App(){
 const [page,setPage]=useState("dashboard"),[base,setBase]=useStored("flo.base","NGN"),[mode,setMode]=useState("pct"),[selected,setSelected]=useState(null),[toast,setToast]=useState("");
 const [transactions,setTransactions]=useStored("flo.transactions",initialTransactions);
 const [accounts,setAccounts]=useStored("flo.accounts",initialAccounts);
 const [thresholds,setThresholds]=useStored("flo.thresholds",{floor:100000,comfort:200000,wealth:500000});
 const [start,setStart]=useStored("flo.start",250000);
 const [modal,setModal]=useState(false);
 const income=transactions.filter(t=>t.type==="income").reduce((s,t)=>s+t.amount,0);
 const expense=transactions.filter(t=>t.type==="expense").reduce((s,t)=>s+t.amount,0);
 const live=start+income-expense;
 const flows=categories.map(c=>{const amount=transactions.filter(t=>t.type==="expense"&&t.category===c.name).reduce((s,t)=>s+t.amount,0);return {...c,amount,pct:expense?amount/expense*100:0}});
 const inflows=incomeCategories.map((name,i)=>{const amount=transactions.filter(t=>t.type==="income"&&t.category===name).reduce((s,t)=>s+t.amount,0);return {name,color:incomeColors[i],amount,pct:income?amount/income*100:0};});
 const heart=live<thresholds.floor?"red":live<=thresholds.wealth?"orange":"green";
 const notify=x=>{setToast(x);setTimeout(()=>setToast(""),1800)};
 const nav=[["dashboard","⌂","Home"],["accounts","▣","Accounts"],["transactions","↕","Transactions"],["budgets","◫","Budgets"],["wealth","♥","Wealth"]];
 useEffect(()=>{if("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(()=>{})},[]);
 const exportData=()=>{const blob=new Blob([JSON.stringify({transactions,accounts,thresholds,start},null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="flo-backup.json";a.click();URL.revokeObjectURL(a.href);notify("Flo backup exported")};
 return <div className="app">
  <aside className="sidebar"><div className="brand"><h1>Flo</h1><small>Follow the flow.</small></div><div className="nav">{nav.map(([id,icon,label])=><button className={page===id?"active":""} onClick={()=>setPage(id)} key={id}>{icon}&nbsp; {label}</button>)}</div></aside>
  <main className="main">
   <header className="header"><div><div className="eyebrow">Flo · Personal v0.1</div><div className="title">{page==="dashboard"?"Where is your money flowing?":nav.find(x=>x[0]===page)?.[2]}</div></div><div className="toolbar"><select value={base} onChange={e=>setBase(e.target.value)}>{currencies.map(c=><option key={c[0]}>{c[0]}</option>)}</select><button onClick={exportData} title="Export backup"><Download size={15}/></button><button className="primary" onClick={()=>setModal(true)}><Plus size={14}/> Account</button></div></header>
   {page==="dashboard"?<Dashboard {...{base,mode,setMode,selected,setSelected,live,heart,thresholds,accounts,money,flows,inflows,transactions,income,expense}}/>:null}
   {page==="accounts"?<Accounts accounts={accounts} setAccounts={setAccounts} money={money} onAdd={()=>setModal(true)}/>:null}
   {page==="transactions"?<Transactions live={live} money={money} transactions={transactions} setTransactions={setTransactions} notify={notify}/>:null}
   {page==="budgets"?<Budgets flows={flows} expense={expense}/>:null}
   {page==="wealth"?<Wealth thresholds={thresholds} setThresholds={setThresholds} start={start} setStart={setStart} live={live}/>:null}
  </main>
  <nav className="bottom">{nav.map(([id,icon,label])=><button className={page===id?"active":""} onClick={()=>setPage(id)} key={id}><span>{icon}</span>{label}</button>)}</nav>
  {modal&&<AccountModal setAccounts={setAccounts} setModal={setModal}/>}
  {toast&&<div className="toast">{toast}</div>}
 </div>
}

function Dashboard({base,mode,setMode,selected,setSelected,live,heart,thresholds,accounts,money,flows,inflows,transactions,income,expense}){
 return <div className="grid">
  <div className="card"><div className="label">Current balance</div><div className="money">{money(live)}</div><div className="stat"><span className="green">+{money(income)}</span><span className="red">−{money(expense)}</span></div></div>
  <div className="card"><div className="label">Income</div><div className="money">{money(income)}</div><div className="sub">{transactions.filter(t=>t.type==="income").length} transactions</div></div>
  <div className="card"><div className="label">Expenses</div><div className="money">{money(expense)}</div><div className="sub">{transactions.filter(t=>t.type==="expense").length} transactions</div></div>
  <div className="card wide"><div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:10}}><div><div className="label">Money Flow Estuary</div><div className="sub">Each particle is an actual expense transaction</div></div><div className="toggle"><button className={mode==="pct"?"on":""} onClick={()=>setMode("pct")}>%</button><button className={mode==="amt"?"on":""} onClick={()=>setMode("amt")}>Amount</button></div></div>
   <div className="estuary bidirectional"><div className="inflowTitle">INFLOW</div><div className="outflowTitle">OUTFLOW</div><div className="source"><div className="sourceIcon">↯</div><b>YOUR MONEY</b><div className="sub">{money(live)} balance</div></div><svg viewBox="0 0 1000 520" preserveAspectRatio="none"><defs>{inflows.map((f,i)=><linearGradient key={"in"+i} id={"ig"+i}><stop stopColor={f.color}/><stop offset="1" stopColor="#fff"/></linearGradient>)}{flows.map((f,i)=><linearGradient key={"out"+i} id={"og"+i}><stop stopColor="#fff"/><stop offset="1" stopColor={f.color}/></linearGradient>)}</defs>{inflows.map((f,i)=>f.amount>0&&<g key={"in"+i}><path className="flowPath inflowPath" d={incomePaths[i]} stroke={"url(#ig"+i+")"} strokeWidth={Math.max(4,f.pct*.8)}/>{transactions.filter(t=>t.type==="income"&&t.category===f.name).map((t,j)=><circle key={t.id} className="moneyParticle" r={Math.max(2,Math.min(11,2+Math.sqrt(t.amount)/35))} fill={f.color}><title>{t.description}: {money(t.amount,t.cur)}</title><animateMotion dur={Math.max(1.5,4.5-t.amount/70000)+"s"} begin={(-j*.6)+"s"} repeatCount="indefinite" path={incomePaths[i]}/></circle>)}</g>)}{flows.map((f,i)=>f.amount>0&&<g key={"out"+i} className={selected!==null&&selected!==i?"dim":""}><path className="flowPath" d={paths[i]} stroke={"url(#og"+i+")"} strokeWidth={Math.max(4,f.pct*.9)} onClick={()=>setSelected(selected===i?null:i)}/>{transactions.filter(t=>t.type==="expense"&&t.category===f.name).map((t,j)=><circle key={t.id} className="moneyParticle" r={Math.max(2,Math.min(11,2+Math.sqrt(t.amount)/35))} fill={f.color}><title>{t.description}: {money(t.amount,t.cur)}</title><animateMotion dur={Math.max(1.5,4.5-t.amount/70000)+"s"} begin={(-j*.6)+"s"} repeatCount="indefinite" path={paths[i]}/></circle>)}</g>)}</svg>{inflows.map((f,i)=>f.amount>0&&<div className="flowLabel inflowLabel" style={{top:[58,125,190,315,400][i]}} key={f.name}><i className="dot" style={{background:f.color}}/><b>{f.name}</b><span>{mode==="pct"?f.pct.toFixed(0)+"%":money(f.amount)}</span></div>)}{flows.map((f,i)=>f.amount>0&&<div className="flowLabel outflowLabel" style={{top:[58,125,190,315,400][i]}} key={f.name} onClick={()=>setSelected(selected===i?null:i)}><i className="dot" style={{background:f.color}}/><b>{f.name}</b><span>{mode==="pct"?f.pct.toFixed(0)+"%":money(f.amount)}</span></div>)}<div className="legend">Inflows move toward Flo · outflows move away · width = percentage · particles = transactions</div></div>
   <svg viewBox="0 0 1000 520" preserveAspectRatio="none"><defs>{flows.map((f,i)=><linearGradient key={i} id={"g"+i}><stop stopColor={f.color}/><stop offset="1" stopColor="#ffffff"/></linearGradient>)}</defs>
   {flows.map((f,i)=><g key={i} className={selected!==null&&selected!==i?"dim":""}><path className="flowPath" d={paths[i]} stroke={"url(#g"+i+")"} strokeWidth={Math.max(4,f.pct*.9)} onClick={()=>setSelected(selected===i?null:i)}/>{transactions.filter(t=>t.type==="expense"&&t.category===f.name).map((t,j)=><circle key={t.id} className="moneyParticle" r={Math.max(2,Math.min(11,2+Math.sqrt(t.amount)/35))} fill={f.color}><title>{t.description}: {money(t.amount,t.cur)}</title><animateMotion dur={Math.max(1.5,4.5-t.amount/70000)+"s"} begin={(-j*.6)+"s"} repeatCount="indefinite" path={paths[i]}/></circle>)}</g>)}</svg>
   {flows.map((f,i)=><div className="flowLabel" style={{top:[58,158,253,329,405][i]}} key={f.name} onClick={()=>setSelected(selected===i?null:i)}><i className="dot" style={{background:f.color}}/><b>{f.name}</b><span>{mode==="pct"?f.pct.toFixed(0)+"%":money(f.amount)}</span></div>)}
   <div className="legend">Width = actual percentage · particle = actual transaction · tap a stream to isolate</div></div>
  </div>
  <div className="card"><div className="label">Flo heart</div><div className="heartWrap"><div className={"heart "+heart}></div><div><b className={heart==="red"?"red":heart==="orange"?"gold":"green"}>{heart==="red"?"Below your floor":heart==="orange"?"Your comfort zone":"Your wealth zone"}</b><div className="sub">{money(live)} · floor {money(thresholds.floor)}</div></div></div></div>
  <div className="card"><div className="label">Accounts</div>{accounts.map(a=><div className="account" key={a.name}><span className="accountLeft"><i className="coin">{a.cur==="BTC"?"₿":a.cur==="ETH"?"Ξ":a.cur[0]}</i><span>{a.name}<small className="sub">{a.cur}</small></span></span><b>{a.cur==="NGN"?money(a.bal,a.cur):a.bal+" "+a.cur}</b></div>)}</div>
 </div>
}

function Transactions({live,money,transactions,setTransactions,notify}){
 const [form,setForm]=useState({description:"",amount:"",category:"Food & Dining",account:"GTBank",cur:"NGN",type:"expense"});
 const add=()=>{if(!form.description||!Number(form.amount))return;setTransactions([{...form,id:Date.now(),amount:Number(form.amount),date:"Just now"},...transactions]);setForm({...form,description:"",amount:""});notify("Transaction added — Estuary updated")};
 return <div className="grid"><div className="card wide"><div className="label">Live balance</div><div className="money">{money(live)}</div><div className="sub">Starting balance + income − expenses</div><div className="transactionForm"><input className="field" placeholder="What was it?" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/><input className="field" type="number" placeholder="Amount" value={form.amount} onChange={e=>setForm({...form,amount:e.target.value})}/><select className="field" value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{(form.type==="expense"?categories.map(c=>c.name):incomeCategories).map(c=><option key={c}>{c}</option>)}</select><select className="field" value={form.type} onChange={e=>{const type=e.target.value;setForm({...form,type,category:type==="expense"?"Food & Dining":"Salary"})}}><option value="expense">Expense</option><option value="income">Income</option></select><button className="primary" onClick={add}>Add</button></div></div><div className="card wide"><div className="label">Transactions</div>{transactions.map(t=><div className="row" key={t.id}><span><b>{t.description}</b><div className="sub">{t.category} · {t.date}</div></span><span><b className={t.type==="income"?"green":"red"}>{t.type==="income"?"+":"−"}{money(t.amount,t.cur)}</b> <button className="close" style={{fontSize:15}} onClick={()=>{setTransactions(transactions.filter(x=>x.id!==t.id));notify("Transaction removed")}}>×</button></span></div>)}</div></div>
}
function Accounts({accounts,setAccounts,money,onAdd}){return <div className="grid"><div className="card wide"><div className="label">Accounts</div>{accounts.map((a,i)=><div className="account" key={a.name}><span className="accountLeft"><i className="coin">{a.cur[0]}</i><span>{a.name}<small className="sub">{a.type} · {a.cur}</small></span></span><span><b>{a.cur==="NGN"?money(a.bal,a.cur):a.bal+" "+a.cur}</b> <button className="close" onClick={()=>setAccounts(accounts.filter((_,j)=>j!==i))}>×</button></span></div>)}<button className="primary" style={{marginTop:12}} onClick={onAdd}>+ Add account</button></div></div>}
function AccountModal({setAccounts,setModal}){const [f,setF]=useState({name:"",cur:"NGN",bal:"",type:"Bank account"});const add=()=>{if(!f.name)return;setAccounts(a=>[...a,{...f,bal:Number(f.bal)||0}]);setModal(false)};return <div className="modal"><div className="modalBox"><div className="modalHead"><b>Add account</b><button className="close" onClick={()=>setModal(false)}>×</button></div><div className="formGrid"><label>Name<input className="field" value={f.name} onChange={e=>setF({...f,name:e.target.value})}/></label><label>Type<select className="field" value={f.type} onChange={e=>setF({...f,type:e.target.value})}><option>Bank account</option><option>Cash wallet</option><option>Crypto wallet</option></select></label></div><label className="full">Currency<select className="field" value={f.cur} onChange={e=>setF({...f,cur:e.target.value})}>{currencies.map(c=><option key={c[0]}>{c[0]}</option>)}</select></label><label className="full">Balance<input className="field" type="number" value={f.bal} onChange={e=>setF({...f,bal:e.target.value})}/></label><button className="primary" style={{width:"100%",marginTop:15}} onClick={add}>Create account</button></div></div>}
function Budgets({flows,expense}){return <div className="grid"><div className="card wide"><div className="label">Where expenses are flowing</div>{flows.map(f=><div style={{marginTop:15}} key={f.name}><div className="row"><span>{f.name}</span><span>{f.pct.toFixed(1)}%</span></div><div className="progress"><i style={{width:f.pct+"%",background:f.color}}/></div></div>)}</div></div>}
function Wealth({thresholds,setThresholds,start,setStart,live}){return <div className="grid"><div className="card wide"><div className="label">Your definition of wealth</div><h2 style={{fontFamily:"Georgia",fontWeight:400}}>You set the thresholds. Flo follows them.</h2><div className="sub">These values control the heart state.</div></div>{[["floor","Financial floor"],["comfort","Comfort threshold"],["wealth","Wealth threshold"]].map(([k,l])=><div className="card" key={k}><div className="label">{l}</div><input className="field" type="number" value={thresholds[k]} onChange={e=>setThresholds({...thresholds,[k]:Number(e.target.value)})}/></div>)}<div className="card"><div className="label">Starting balance</div><input className="field" type="number" value={start} onChange={e=>setStart(Number(e.target.value))}/><div className="sub">Current balance: {money(live)}</div></div></div>}
createRoot(document.getElementById("root")).render(<App/>);
